#!/usr/bin/python
# -*- coding: utf-8 -*-
#sqltest.py - Fetch and display the MySQL database server version.
# import the MySQLdb and sys modules
#deletes first row, runs after the robot finishes order.
import MySQLdb
import sys
import os
import time
os.system("python go_to_v1.py "+checker)
