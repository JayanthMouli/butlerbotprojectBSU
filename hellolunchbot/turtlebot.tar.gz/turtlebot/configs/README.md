# Configs for Lunchbot

## bashrc

### Environmental Variables

### Aliases

## /turtlebot/devel/setup.sh

### Environmental Variables

### Aliases

## Common Commands

## Common Errors Seen
